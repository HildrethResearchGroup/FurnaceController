/*
 *  DGTextCommandConstants.h
 *  DataGraph
 *
 *  Created by David Adalsteinsson on 7/8/09.
 *  Copyright 2009-2013 Visual Data Tools, Inc. All rights reserved.
 *
 */

