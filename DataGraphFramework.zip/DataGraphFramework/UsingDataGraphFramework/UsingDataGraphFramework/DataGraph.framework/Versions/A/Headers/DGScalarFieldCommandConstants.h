//
//  DGScalarFieldCommandConstants.h
//  DataGraph
//
//  Created by David Adalsteinsson on 8/26/15.
//  Copyright (c) 2015 Visual Data Tools, Inc. All rights reserved.
//

typedef enum _DGScalarFieldCommandLayout {
    DGScalarFieldCommandFlattened     = 1,
} DGScalarFieldCommandLayout;

