//
//  DGColorsCommand.h
//  DataGraph
//
//  Created by David Adalsteinsson on 10/12/09.
//  Copyright 2009-2013, Visual Data Tools Inc. All rights reserved.
//

#import "DGCommand.h"

#import "DGFitCommandConstants.h"

@interface DGColorsCommand : DGCommand {

}

@end
