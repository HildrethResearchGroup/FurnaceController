//
//  DGBarCommand.h
//  Crop Region
//
//  Created by David Adalsteinsson on 6/27/09.
//  Copyright 2009-2013, Visual Data Tools Inc. All rights reserved.
//

#import "DGCommand.h"

@interface DGBarCommand : DGCommand {
    
}

- (DGLineStyleSettings *)line;

@end