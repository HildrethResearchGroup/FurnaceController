//
//  DGLabelCommand.h
//
//  Created by David Adalsteinsson
//  Copyright 2009-2013 Visual Data Tools, Inc. All rights reserved.
//

#import "DGCommand.h"


@interface DGLabelCommand : DGCommand {

}

@end
