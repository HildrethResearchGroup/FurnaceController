//
//  UsingDataGraphFrameworkApp.swift
//  UsingDataGraphFramework
//
//  Created by Owen Hildreth on 12/18/21.
//

import SwiftUI

@main
struct UsingDataGraphFrameworkApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
